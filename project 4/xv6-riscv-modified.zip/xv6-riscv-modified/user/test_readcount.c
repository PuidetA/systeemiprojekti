// Test the getreadcount functions

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"

int main() {
  char buffer[1024];
  int file = open("README", O_RDONLY); // We will test the function by reading README

  if (file < 0) {
    printf("Failed to open the README file\n"); // Not sure if perror works on xv6 consistently, sticking with what I know will work for sure since we weren't given rules on this task.
    exit(1);
  }

  printf("Starting read count: %d\n", getreadcount(0));

  // testing reading 5 times
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);

  printf("After 5 reads we have: %d\n", getreadcount(0));

  printf("Now we reset the readcount.\n");
  getreadcount(1);

  printf("After the reset: %d\n", getreadcount(0));

  printf("Now we test disabling.\n");
  getreadcount(3);
  printf("Disabled counting.\n");
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);
  printf("Readcount after 3 reads: %d\n", getreadcount(0));

  printf("Now we test enabling.\n");
  getreadcount(2);
  printf("Enabled counting.\n");
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);
  read(file, buffer, 10);
  printf("Readcount after 9 reads: %d\n", getreadcount(0));


  close(file);
  exit(0);
}
