#include "kernel/types.h"
#include "user/user.h"
#include "kernel/param.h"

int
main(int argc, char *argv[])
{
  int param = 0;

  if (argc > 1) {
    param = atoi(argv[1]);
  }

  int value = getreadcount(param);

  if (param == 0) {
    printf("Syscall read's readcount: %d\n", value);
  }

  exit(0);
}
